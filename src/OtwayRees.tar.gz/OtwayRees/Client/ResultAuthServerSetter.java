package OtwayRees.Client;

import OtwayRees.Message;

/**
 * Created on 14.05.15.
 */
public interface ResultAuthServerSetter {
    void setResultSetter(Message msg);
}
