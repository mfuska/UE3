package OtwayRees.Client;

/**
 * Created on 10.05.15.
 */
public interface ResultSetter {
    void setResult(String name);
    void setResult(String nameA, String nameB);
}
